# MasumPDF Reader

A free, open-source desktop PDF application written in Python.
Open, read, annotate, sign, organize, convert, OCR, compare,
compress, fill forms, stamp, and protect PDF files from one window.

**Author:** Chowdhury Mohammad Masum Refat
**License:** MIT License (free for personal and commercial use)
**Version:** 1.0.0

---

## What it does

- View PDFs with continuous scroll, single page, or two-page mode.
- Smooth zoom (Ctrl + mouse wheel), rotate, fit-width, fit-page, full screen.
- Page thumbnails on the left, comments and properties on the right.
- Multi-tab interface, drag and drop, recent files.
- Light and dark theme.
- Search inside a PDF with highlighting and next / previous navigation.
- Create blank PDFs (A4, A3, A5, Letter, Legal, Tabloid).
- Annotations: highlight (drag), sticky notes, comments, stamps (standard + custom).
- Prepare forms (text, checkbox, dropdown, listbox, signature fields).
- Fill and sign existing forms; save flattened copies.
- Signatures: typed, drawn, or uploaded image — click on the page to place.
- Rich media: web links, internal jumps, file attachments, audio/video.
- Send for review: email summary of comments with the recipient's mail client.
- Page organization: reorder, rotate, delete, duplicate, extract, split, merge.
- Convert PDF to images (PNG / JPG), images to PDF, PDF to plain text.
- Optional PDF to DOCX if `python-docx` is installed.
- OCR scanned PDFs into searchable PDFs using Tesseract.
- Compare two PDFs side-by-side with a per-page text diff.
- Compress PDFs by downsampling images (50–300 DPI, JPEG quality).
- Change text color on a page.
- Encrypt and decrypt PDFs, view permissions.
- View and edit metadata (title, author, subject, keywords).
- Autosave for dirty documents at a configurable interval.

---

## Install

### Windows (easy way)

Just double-click **`SETUP.bat`**. That one file does everything —
it installs Python if needed, installs all the parts, builds the app,
and puts an icon on your Desktop. Then double-click `run.bat` (or the
Desktop icon) to start.

See `HOW_TO_INSTALL.txt` for the simple step-by-step.

### macOS / Linux

You need Python 3.9 or newer.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

### OCR (optional)

The OCR feature needs the **Tesseract** binary installed separately:

- **Windows:** https://github.com/UB-Mannheim/tesseract/wiki
- **macOS:** `brew install tesseract`
- **Ubuntu/Debian:** `sudo apt install tesseract-ocr`

Without Tesseract, every feature except OCR still works. The OCR button
shows a clear message if Tesseract is missing.

---

## Run

```bash
python main.py
```

Pass PDFs on the command line to open them at startup:

```bash
python main.py document.pdf another.pdf
```

On Windows you can also drag-and-drop PDFs onto `run.bat`.

---

## Keyboard shortcuts

| Action            | Shortcut         |
|-------------------|------------------|
| New blank PDF     | Ctrl + N         |
| Open              | Ctrl + O         |
| Save              | Ctrl + S         |
| Save As           | Ctrl + Shift + S |
| Close tab         | Ctrl + W         |
| Quit              | Ctrl + Q         |
| Zoom in           | Ctrl + =         |
| Zoom out          | Ctrl + -         |
| Fit width         | Ctrl + 1         |
| Fit page          | Ctrl + 2         |
| Rotate view 90°   | Ctrl + R         |
| Full screen       | F11              |
| Toggle theme      | Ctrl + T         |
| Find              | Ctrl + F         |
| Zoom (smooth)     | Ctrl + mouse wheel |

---

## Project layout

```
masumpdf_reader/
├── main.py                       # entry point
├── LICENSE                       # MIT License
├── requirements.txt
├── README.md
├── install.bat                   # Windows: first-time setup
├── run.bat                       # Windows: launch the app
├── run-debug.bat                 # Windows: launch with console for errors
├── ui/
│   ├── main_window.py            # main window, menus, tabs, actions
│   ├── pdf_viewer.py             # scrollable PDF canvas + tool modes
│   ├── toolbar.py                # top toolbar with all buttons
│   ├── sidebar.py                # thumbnails / outline / comments / props
│   ├── dialogs.py                # all dialogs
│   └── styles.py                 # light + dark Qt stylesheets
├── core/
│   ├── pdf_document.py           # wraps fitz.Document, renders pages
│   ├── pdf_creator.py            # blank PDF generator
│   ├── annotation_manager.py     # highlights, notes, drawings, signatures
│   ├── form_manager.py           # form fields: add, list, fill, flatten
│   ├── stamp_manager.py          # standard + custom stamps
│   ├── media_manager.py          # links, attachments, media pointers
│   ├── page_manager.py           # merge, split, extract
│   ├── converter.py              # PDF ↔ images, PDF → text / DOCX
│   ├── compressor.py             # compression with DPI options
│   ├── comparer.py               # side-by-side comparison + text diff
│   ├── text_editor.py            # change text color on a page
│   ├── security.py               # encrypt / decrypt with pypdf
│   ├── metadata.py               # read / write document metadata
│   └── ocr_engine.py             # pytesseract searchable-PDF writer
├── utils/
│   ├── constants.py
│   ├── settings.py               # QSettings wrapper
│   ├── file_utils.py
│   └── worker_threads.py         # QThread workers for heavy jobs
└── resources/
    ├── icons/                    # drop your own .png icons here
    └── themes/                   # extra theme files
```

---

## Honest notes

I want to be straight about a few things:

- **Request e-signature** — a full e-sign workflow (signing link, audit
  trail, tamper-evident certificate) needs a cloud service. The local
  equivalent in this app: use *Prepare Form* to drop an empty signature
  field, save the file, and send it. The recipient signs in their own
  PDF viewer.
- **Rich media (video/audio)** — PDF supports embedded video, but most
  PDF viewers won't play it. The most portable option is what this app
  uses: embed the media as a file attachment and put a clickable label
  on the page. Clicking opens the file with the OS default player.
- **Other annotations** — underline, strikeout, freehand ink, shapes,
  text boxes have engine code in `annotation_manager.py` but no dedicated
  toolbar buttons yet.
- **Redaction** — not implemented yet.
- **Text-to-speech** — not implemented.
- **Print** — toolbar button signal exists but no print handler. Save
  the file and print from the OS viewer.

Everything else works.

---

## License

This software is released under the MIT License — see the `LICENSE` file
for the full text. In short:

- Free to use for personal and commercial purposes.
- Free to copy, modify, and distribute.
- No warranty.

© 2026 Chowdhury Mohammad Masum Refat.
