@echo off
REM ============================================================
REM  MasumPDF Reader - Uninstall
REM  Created by Chowdhury Mohammad Masum Refat (MIT License)
REM
REM  This removes the things SETUP.bat created:
REM    - the app environment (.venv) and built program (app_exe)
REM    - the Desktop shortcut
REM    - the PDF file-association registry entries
REM
REM  It does NOT delete Python (you may need it for other things)
REM  and does NOT delete this folder itself - you can delete the
REM  folder by hand afterwards if you want.
REM ============================================================

setlocal
cd /d "%~dp0"

echo.
echo   ===========================================
echo    MasumPDF Reader - Uninstall
echo   ===========================================
echo.
echo   This will remove the app's environment, the built program,
echo   the Desktop shortcut, and the PDF file association.
echo.
choice /C YN /M "Are you sure you want to uninstall"
if errorlevel 2 goto :cancel

echo.
echo   Removing the app environment ...
if exist ".venv"    rmdir /s /q ".venv"    2>nul
if exist "app_exe"  rmdir /s /q "app_exe"  2>nul
if exist "build"    rmdir /s /q "build"    2>nul
if exist "dist"     rmdir /s /q "dist"     2>nul
if exist "MasumPDFReader.spec" del /q "MasumPDFReader.spec" 2>nul

echo   Removing the Desktop shortcut ...
if exist "%USERPROFILE%\Desktop\MasumPDF Reader.lnk" del /q "%USERPROFILE%\Desktop\MasumPDF Reader.lnk" 2>nul

echo   Removing the PDF file association ...
reg delete "HKCU\Software\Classes\MasumPDFReader.Document" /f >nul 2>nul
reg delete "HKCU\Software\Classes\.pdf\OpenWithProgids" /v "MasumPDFReader.Document" /f >nul 2>nul
ie4uinit.exe -show >nul 2>nul

echo.
echo   ===========================================
echo    Uninstall complete.
echo
echo    Note:
echo     - Python was NOT removed (other programs may use it).
echo       To remove Python: Settings ^> Apps ^> find Python ^> Uninstall.
echo     - You can now delete this whole folder by hand if you wish.
echo   ===========================================
echo.
pause
goto :end

:cancel
echo.
echo   Uninstall cancelled. Nothing was changed.
echo.
pause

:end
endlocal
