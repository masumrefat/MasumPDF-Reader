"""PDF document wrapper.

Wraps PyMuPDF (fitz) so the UI code never touches fitz directly.
This keeps PDF logic in one place and makes the UI easy to test or swap.
"""

import os
import fitz   # PyMuPDF
from PySide6.QtGui import QImage, QPixmap


class PDFDocument:
    """Represents one open PDF file with helpers for rendering, search, etc."""

    def __init__(self, path: str, password: str | None = None):
        self.path = path
        self.password = password or ""
        self.doc = fitz.open(path)
        self._dirty = False

        # Undo support: snapshots of the document bytes taken right before
        # each edit. Undo restores the most recent snapshot. PDFs have no
        # native undo, so a byte-snapshot stack is the most reliable approach
        # and works uniformly for text, images, highlights, stamps, etc.
        self._undo_stack: list[bytes] = []
        self._undo_labels: list[str] = []
        self._max_undo = 12   # cap memory use

        if self.doc.needs_pass:
            if not password or not self.doc.authenticate(password):
                # leave the document open but mark it as locked
                self._locked = True
            else:
                self._locked = False
        else:
            self._locked = False

    # ---- basic properties ----
    @property
    def is_locked(self) -> bool:
        return self._locked

    @property
    def page_count(self) -> int:
        return self.doc.page_count

    @property
    def dirty(self) -> bool:
        return self._dirty

    def mark_dirty(self, value: bool = True):
        self._dirty = value

    # ---- undo support ----
    def push_undo(self, label: str = "edit"):
        """Snapshot current document bytes before an edit, so it can be undone.
        Call this immediately BEFORE making a change."""
        try:
            snapshot = self.doc.tobytes(deflate=True)
        except Exception:
            # if snapshotting fails, skip silently — better than crashing
            return
        self._undo_stack.append(snapshot)
        self._undo_labels.append(label)
        # cap the stack
        if len(self._undo_stack) > self._max_undo:
            self._undo_stack.pop(0)
            self._undo_labels.pop(0)

    def can_undo(self) -> bool:
        return len(self._undo_stack) > 0

    def last_undo_label(self) -> str:
        return self._undo_labels[-1] if self._undo_labels else ""

    def undo(self) -> bool:
        """Restore the most recent snapshot. Returns True if something was
        undone. The current document is replaced by the snapshot."""
        if not self._undo_stack:
            return False
        snapshot = self._undo_stack.pop()
        self._undo_labels.pop()
        try:
            new_doc = fitz.open(stream=snapshot, filetype="pdf")
        except Exception:
            return False
        try:
            self.doc.close()
        except Exception:
            pass
        self.doc = new_doc
        self._dirty = True
        return True

    def clear_undo(self):
        self._undo_stack.clear()
        self._undo_labels.clear()

    def delete_annot_at(self, page_index: int, x: float, y: float,
                        radius: float = 6.0) -> str | None:
        """Delete the topmost annotation whose rectangle contains (or is
        near) the point. Returns a short description of what was deleted,
        or None if nothing was found.

        Handles text, highlights, stamps, comments, signatures, links —
        anything stored as a PDF annotation. (Inserted images that became
        page content are not annotations; use Undo for those.)"""
        if not self.doc or page_index < 0 or page_index >= self.doc.page_count:
            return None
        page = self.doc[page_index]
        pt = fitz.Point(x, y)

        # Collect candidate annotations in one pass, capturing the data we
        # need immediately (reading annot properties lazily later can crash
        # PyMuPDF if the page's annot list changes). We pick the smallest
        # annotation containing the point so overlapping annots resolve to
        # the most specific one.
        best = None          # (area, description, annot)
        try:
            for annot in (page.annots() or []):
                try:
                    r = annot.rect
                except Exception:
                    continue
                rr = fitz.Rect(r.x0 - radius, r.y0 - radius,
                               r.x1 + radius, r.y1 + radius)
                if not rr.contains(pt):
                    continue
                # capture description now, while the handle is valid
                try:
                    atype = annot.type[1] if annot.type else "annotation"
                except Exception:
                    atype = "annotation"
                try:
                    content = (annot.info or {}).get("content", "") or ""
                except Exception:
                    content = ""
                desc = atype + (f": {content[:30]}" if content else "")
                area = max(0.0, r.width) * max(0.0, r.height)
                if best is None or area < best[0]:
                    best = (area, desc, annot)
        except Exception:
            return None

        if best is None:
            return None

        _, desc, hit = best
        try:
            page.delete_annot(hit)
            self.mark_dirty()
            return desc
        except Exception:
            return None

    def file_name(self) -> str:
        return os.path.basename(self.path) if self.path else "Untitled"

    # ---- metadata ----
    def metadata(self) -> dict:
        md = dict(self.doc.metadata or {})
        md["file_path"] = self.path
        md["file_size"] = os.path.getsize(self.path) if self.path and os.path.isfile(self.path) else 0
        md["page_count"] = self.page_count
        md["encrypted"] = bool(self.doc.is_encrypted)
        md["is_pdf"] = self.doc.is_pdf
        return md

    def set_metadata(self, md: dict):
        self.doc.set_metadata(md)
        self._dirty = True

    # ---- rendering ----
    def render_page(self, page_index: int, zoom: float = 1.0, rotation: int = 0,
                    dpi: int | None = None) -> QPixmap:
        """Render a page to a QPixmap. zoom 1.0 = 100%, dpi overrides if set."""
        page = self.doc.load_page(page_index)
        if dpi:
            zoom_factor = dpi / 72.0
        else:
            zoom_factor = zoom
        mat = fitz.Matrix(zoom_factor, zoom_factor)
        if rotation:
            mat = mat * fitz.Matrix(rotation)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        fmt = QImage.Format_RGB888
        img = QImage(pix.samples, pix.width, pix.height, pix.stride, fmt)
        # take a copy so the underlying bytes are owned by Qt
        return QPixmap.fromImage(img.copy())

    def render_thumbnail(self, page_index: int, width: int = 150) -> QPixmap:
        """Render a small thumbnail with a target width in pixels."""
        page = self.doc.load_page(page_index)
        page_w = page.rect.width or 1
        # render at 2x so it looks sharp on hi-DPI screens
        scale = (width * 2) / page_w
        mat = fitz.Matrix(scale, scale)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        img = QImage(pix.samples, pix.width, pix.height, pix.stride,
                     QImage.Format_RGB888)
        qpix = QPixmap.fromImage(img.copy())
        qpix.setDevicePixelRatio(2.0)
        return qpix

    def page_size(self, page_index: int) -> tuple[float, float]:
        page = self.doc.load_page(page_index)
        return page.rect.width, page.rect.height

    # ---- text & search ----
    def page_text(self, page_index: int) -> str:
        return self.doc.load_page(page_index).get_text()

    def all_text(self) -> str:
        return "\n".join(self.page_text(i) for i in range(self.page_count))

    def search_text(self, term: str, case_sensitive: bool = False, whole_word: bool = False):
        """
        Search for `term` in the document.
        Returns: dict {page_index: [fitz.Rect, ...]}
        """
        if not term:
            return {}
        flags = 0
        if not case_sensitive:
            # fitz default is case-insensitive; nothing to do
            pass
        results: dict[int, list] = {}
        for i in range(self.page_count):
            page = self.doc.load_page(i)
            try:
                hits = page.search_for(term, quads=False)
            except Exception:
                hits = []
            if whole_word and hits:
                # filter by word boundaries — simple approach using the page text
                words = page.get_text("words")
                wanted = term.lower() if not case_sensitive else term
                filtered = []
                for rect in hits:
                    for w in words:
                        wx0, wy0, wx1, wy1, wtext, *_ = w
                        wt = wtext if case_sensitive else wtext.lower()
                        if wt == wanted and abs(wx0 - rect.x0) < 1 and abs(wy0 - rect.y0) < 1:
                            filtered.append(rect)
                            break
                hits = filtered
            if hits:
                results[i] = hits
        return results

    # ---- outline / bookmarks ----
    def outline(self) -> list:
        """Return the table-of-contents as [(level, title, page_index), ...]"""
        toc = self.doc.get_toc(simple=True)
        # toc entries are 1-indexed; convert to 0-indexed
        return [(level, title, page - 1) for level, title, page in toc]

    # ---- saving ----
    def save(self, output_path: str | None = None, incremental: bool = False,
             garbage: int = 4, deflate: bool = True):
        """Save the PDF. If output_path is None, save in place."""
        target = output_path or self.path
        if target == self.path and incremental:
            self.doc.save(target, incremental=True, encryption=fitz.PDF_ENCRYPT_KEEP)
        else:
            self.doc.save(target, garbage=garbage, deflate=deflate)
        if not output_path:
            self._dirty = False

    def close(self):
        try:
            self.doc.close()
        except Exception:
            pass

    # ---- page operations ----
    def delete_page(self, page_index: int):
        self.doc.delete_page(page_index)
        self._dirty = True

    def rotate_page(self, page_index: int, degrees: int):
        page = self.doc.load_page(page_index)
        page.set_rotation((page.rotation + degrees) % 360)
        self._dirty = True

    def move_page(self, from_index: int, to_index: int):
        # fitz uses move_page(pno, to)
        self.doc.move_page(from_index, to_index)
        self._dirty = True

    def insert_pdf(self, other_path: str, start_page: int | None = None):
        other = fitz.open(other_path)
        if start_page is None:
            self.doc.insert_pdf(other)
        else:
            self.doc.insert_pdf(other, start_at=start_page)
        other.close()
        self._dirty = True

    def duplicate_page(self, page_index: int):
        self.doc.copy_page(page_index, page_index + 1)
        self._dirty = True

    def extract_pages(self, page_indices: list, output_path: str):
        """Save selected pages as a new PDF."""
        new_doc = fitz.open()
        for idx in page_indices:
            new_doc.insert_pdf(self.doc, from_page=idx, to_page=idx)
        new_doc.save(output_path, garbage=4, deflate=True)
        new_doc.close()
